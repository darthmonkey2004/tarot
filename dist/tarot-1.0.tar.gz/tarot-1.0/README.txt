3 card tarot example using PySimpleGUI and base64 encoded strings

non-installed - Just run main.py in tarot package directory.
installed - Run 'pip3 install --user 'dist/tarot-1.0.tar.gz' from get repo root (where setup.py resides)

